# zerone_books
## A basic odoo module project as an example 
An basic module to manage the books if it is necessary in a library. With the basic features to write and change the data in the database. and it has some basic frontend views. 

The running environment is Odoo 13 comunity version


P.S. This is although a basic module in odoo, but I have made quite an effort to understand the python, django and odoo structure and some other knowledge. This is just a milestone for me. Hooray
